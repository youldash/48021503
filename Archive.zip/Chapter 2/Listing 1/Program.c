//
//  Program.c
//  Listing 1
//
//  Created by Mustafa Youldash on 6/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

// function main begins program execution
int main(void) {
    
    printf("Welcome to C!\n");
    
    return 0;
    
} // end function main
