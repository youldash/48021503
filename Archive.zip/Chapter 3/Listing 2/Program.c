//
//  Program.c
//  Listing 2
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    printf(" (1) %d\n", 455);
    printf(" (2) %i\n", 455);
    printf(" (3) %d\n", -455);
    printf(" (4) %o\n", 455);
    printf(" (5) %u\n", 455);
    printf(" (6) %u\n", -455);
    printf(" (7) %x\n", 455);
    printf(" (8) %X\n", 455);
    return 0;
}
