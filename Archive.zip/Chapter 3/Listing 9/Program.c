//
//  Program.c
//  Listing 9
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    char var1;
    printf("Enter character: ");
    scanf("%c", &var1);
    printf("You entered %c.\n", var1);

    return 0;
}
