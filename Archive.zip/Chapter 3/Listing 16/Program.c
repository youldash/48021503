//
//  Program.c
//  Listing 16
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    int grade = 48;
    int total = 155;
    float average;
    
    average = total / grade ;
    
    printf("average = %f\n", average);

    return 0;
}
