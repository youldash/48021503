//
//  Program.c
//  Listing 4
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    char character = 'A';
    char string[] = "This is a string";
    printf("%c\n", character);
    printf("%s\n", "This is a string");
    printf("%s\n", string);

    return 0;
}
