//
//  Program.c
//  Listing 12
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    int a=9, b=4, c;
    
    c=a+b;   printf("a+b=%d\n",c);
    c=a-b;   printf("a-b=%d\n",c);
    c=a*b;   printf("a*b=%d\n",c);
    c=a/b;   printf("a/b=%d\n",c);
    c=a%b;   printf("Remainder when a divided by b=%d\n",c);

    return 0;
}
