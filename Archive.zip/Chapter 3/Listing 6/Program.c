//
//  Program.c
//  Listing 6
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    int x;
    printf("Enter a number\n");
    scanf("%d", &x);
    printf("Number = %d\n", x);

    return 0;
}
