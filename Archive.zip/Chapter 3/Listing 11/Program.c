//
//  Program.c
//  Listing 11
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    int var1 = 69;
    printf("Character of ASCII value 69 is %c\n",var1);

    return 0;
}
