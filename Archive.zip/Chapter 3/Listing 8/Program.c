//
//  Program.c
//  Listing 8
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    float a;
    printf("Enter value: ");
    scanf("%f", &a);
    printf("Value = %f\n", a);

    return 0;
}
