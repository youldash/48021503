//
//  Program.c
//  Listing 3
//
//  Created by Mustafa Youldash on 8/3/17.
//  Copyright © 2017 Umm Al-Qura University. All rights reserved.
//

#include <stdio.h>

int main(void) {
    
    printf(" (1) %e\n", 1234567.89);
    printf(" (2) %e\n", -1234567.89);
    printf(" (3) %E\n", 1234567.89);
    printf(" (4) %f\n", 1234567.89);
    printf(" (5) %g\n", 1234567.89);
    printf(" (6) %G\n", 1234567.89);
    return 0;
}
